//
//  Menuname+CoreDataClass.swift
//  NavigationMenu
//
//  Created by Workstation 158 on 21/06/19.
//  Copyright © 2019 learn. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Menuname)
public class Menuname: NSManagedObject {

}
