//
//  coreDataFunction.swift
//  NavigationMenu
//
//  Created by Workstation 158 on 11/04/19.
//  Copyright © 2019 learn. All rights reserved.
//
//9131240811 nan c
import Foundation
import CoreData
import UIKit

class alertMessage {
    
}
class coreDataFunction:UIViewController,UIAlertViewDelegate {
    
    let managedContext = ((UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext)
    func someEntityExists(menuname: String) -> Bool {
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Menuname")
        fetchRequest.predicate = NSPredicate(format: "menu = %d", menuname)
        var results: [NSManagedObject] = []
        do {
            results = try managedContext.fetch(fetchRequest)
        }
        catch {
            print("error executing fetch request: \(error)")
        }
        return results.count > 1
    }
    
    func alertMessage(alertmsg: String) -> UIAlertController {
        let alert = UIAlertController(title: "Alert", message: alertmsg, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        return alert
    }
    
    func saveDataIntoCoreDataEntity(imgData :Data, menu: String, menuID: String) -> Bool {
        var isSave : Bool = false
        let menumanagedModel = NSEntityDescription.entity(forEntityName:"Menuname" , in:managedContext)
        let newUser = NSManagedObject(entity: menumanagedModel!,insertInto:managedContext)
        newUser.setValue(menu, forKey: "menu")
        newUser.setValue(menuID, forKey: "menuid")
        newUser.setValue(imgData, forKey: "image")
        
        // Create Relationaship b/w two table and insert data into other Entity.
        
        let submenumanagedModel = NSEntityDescription.entity(forEntityName:"Relational" , in:managedContext)
        let subnewmenu = NSManagedObject(entity: submenumanagedModel!,insertInto:managedContext)
        //        subnewmenu.setValue(4,forKey: "submenuid")
        subnewmenu.setValue(menu,forKey: "submenuname")
        newUser.setValue(subnewmenu, forKey: "relationship")
        do {
            try newUser.managedObjectContext?.save()
            isSave = true
        }
            
            //        do {
            //            try managedContext.save()
            //            isSave = true
            //        }
        catch let error as NSError {
            isSave = false
            print("Could not save. \(error), \(error.userInfo)")
        }
        return isSave
    }
}

