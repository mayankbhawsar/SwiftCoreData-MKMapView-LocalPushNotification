//
//  UpdateVC.swift
//  NavigationMenu
//
//  Created by Workstation 158 on 04/05/19.
//  Copyright © 2019 learn. All rights reserved.
//

import Foundation
import CoreData
import UIKit
import Messages
var getrecord = NSManagedObject()
class UpdateVC: UIViewController {
    @IBOutlet weak var txtMenu: UITextField!
    @IBOutlet weak var txtSubMenu: UITextField!
    let context = ((UIApplication.shared.delegate) as! AppDelegate).persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()
        txtMenu.isEnabled = false
        txtMenu.text = getrecord.value(forKey: "menu") as? String
        txtSubMenu.text = getrecord.value(forKey: "menuid") as? String
    }
    @IBAction func btn_back(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
//        let evc = self.storyboard?.instantiateViewController(withIdentifier: "eventCreator") as! eventCreator
//        self.present(evc, animated: true, completion: nil)
    }
    @IBAction func btnUpdateRecord(_ sender: Any) {
        let entitidec = NSEntityDescription.entity(forEntityName: "Menuname",in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Menuname")
        request.entity = entitidec
        let pred = NSPredicate(format: "menu =%@", txtMenu.text!)
        request.predicate = pred
        do {
            let result = try context.fetch(request)
            if result.count > 0 {
                let manage = result[0] as! NSManagedObject
                manage.setValue(txtMenu.text!, forKey: "menu")
                manage.setValue(txtSubMenu.text!, forKey: "menuid")
        
                // manage.setValue(5,forKey: "submenuid")
                // Create Relationaship b/w two table and insert data into other Entity.
                
                let submenumanagedModel = NSEntityDescription.entity(forEntityName:"Relational",in:context)
                let request1 = NSFetchRequest<NSFetchRequestResult>(entityName: "Relational")
                request1.entity = submenumanagedModel
                let pred1 = NSPredicate(format: "submenuname =%@", txtMenu.text!)
                request1.predicate = pred1
                do {
                    let result1 = try context.fetch(request1)
                    if result1.count > 0 {
                        let manage1 = result1[0] as! NSManagedObject
                        manage1.setValue(txtMenu.text!,forKey: "submenuname")
                        //                      manage1.setValue(UUID.self,forKey: "submenuid")
                        manage.setValue(manage1, forKey: "relationship")
                    }
                }
                catch {
                    print("Record Not Found")
                }
                
                try manage.managedObjectContext?.save()
                let alert = coreDataFunction().alertMessage(alertmsg: "Successfully Updated")
                self.present(alert, animated: true, completion: nil)
            }
            else {
                print("Record Not Found")
            }
        } catch {
        }
    }
}
