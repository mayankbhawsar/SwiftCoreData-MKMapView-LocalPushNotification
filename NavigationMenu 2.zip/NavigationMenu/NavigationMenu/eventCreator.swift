//
//  eventCreator.swift
//  NavigationMenu
//
//  Created by Workstation 158 on 13/05/19.
//  Copyright © 2019 learn. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation
import MapKit
import CoreLocation
class eventCreator: UIViewController ,CLLocationManagerDelegate,MKMapViewDelegate{
    @IBOutlet weak var map: MKMapView!
    var locationManager = CLLocationManager()
    var addressString : String = " "
    let addresstolatlong  = "Udaipur, Rajasthan"
    var latt: CLLocationDegrees = 0.0 //"24.5872351"
    var longg:CLLocationDegrees = 0.0 // "73.7105731"
    var route = MKRoute()
    override func viewDidLoad() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert]) {
            (granted, error) in
            if granted {
                print("yes")
            } else {
                print("No")
            }
        }
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        map.delegate = self
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
     }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getLocation(from: addresstolatlong) { location in
            self.latt = location!.latitude
            self.longg = location!.longitude
            print("Location is lat=", location?.latitude as Any,"long =",location?.longitude as Any)
        }
    }
    
    func getLocation(from address: String, completion: @escaping (_ location: CLLocationCoordinate2D?)-> Void) {
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(address) { (placemarks, error) in
            guard let placemarks = placemarks,
                let location = placemarks.first?.location?.coordinate  else {
                    return
            }
            //              print(placemarks)
            completion(location)
        }
    }
    func getAddressFromLatLon(pdblLatitude: String, withLongitude pdblLongitude: String) -> String {
        var center : CLLocationCoordinate2D = CLLocationCoordinate2D()
        let lat: Double = Double("\(pdblLatitude)")!
        //21.228124
        let lon: Double = Double("\(pdblLongitude)")!
        //72.833770
        let ceo: CLGeocoder = CLGeocoder()
        center.latitude = lat
        center.longitude = lon
        self.addressString = ""
        let loc: CLLocation = CLLocation(latitude:center.latitude, longitude: center.longitude)
        ceo.reverseGeocodeLocation(loc, completionHandler: {(placemarks, error) in
            if (error != nil)
            {
                print("reverse geodcode fail: \(error!.localizedDescription)")
            }
            let pm = placemarks!
            
            if pm.count > 0 {
                let pm = placemarks!.first!
                
                if pm.subLocality != nil {
                    self.addressString = self.addressString + pm.subLocality! + ", "
                }
                if pm.thoroughfare != nil {
                    self.addressString = self.addressString + pm.thoroughfare! + ", "
                }
                if pm.locality != nil {
                    self.addressString = self.addressString + pm.locality! + ", "
                }
                if pm.country != nil {
                    self.addressString = self.addressString + pm.country! + ", "
                }
                if pm.postalCode != nil {
                    self.addressString = self.addressString + pm.postalCode! + ", "
                }
                
                print(self.addressString)
            }
        })
        return self.addressString
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        if annotation is MKUserLocation {
            return nil
        }
        
        let reuseId = "pinIdentifier"
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        if pinView == nil {
            
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
        }
        else {
            pinView!.annotation = annotation
        }
        let subtitleView = UILabel()
        //Decalare distanceInMeters as global variables so that you can show distance on subtitles
        print(self.route.distance/1000)
        subtitleView.text = String.init(self.route.distance/1000) + "km"
        pinView!.detailCalloutAccessoryView = subtitleView
        return pinView
    }
    func showRouteOnMap(pickupCoordinate: CLLocationCoordinate2D, destinationCoordinate: CLLocationCoordinate2D) {
        
        let sourcePlacemark = MKPlacemark(coordinate: pickupCoordinate, addressDictionary: nil)
        let destinationPlacemark = MKPlacemark(coordinate: destinationCoordinate, addressDictionary: nil)
        
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
        let destinationMapItem = MKMapItem(placemark: destinationPlacemark)
        
        let sourceAnnotation = MKPointAnnotation()
        
        if let location = sourcePlacemark.location {
            sourceAnnotation.coordinate = location.coordinate
        }
        let destinationAnnotation = MKPointAnnotation()
        
        if let location = destinationPlacemark.location {
            destinationAnnotation.coordinate = location.coordinate
        }
        
        self.map.showAnnotations([sourceAnnotation,destinationAnnotation], animated: true )
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = sourceMapItem
        directionRequest.destination = destinationMapItem
        directionRequest.transportType = .automobile
        directionRequest.requestsAlternateRoutes = true
        // Calculate the direction
        let directions = MKDirections(request: directionRequest)
        
        directions.calculate {(response, error) -> Void in
            
            guard let response = response else {
                if let error = error {
                    print("Error: \(error)")
                }
                return
            }            
            self.route = response.routes[0]
            //            print(self.route.distance)
            self.map.addOverlay((self.route.polyline), level: MKOverlayLevel.aboveRoads)
            let rect = self.route.polyline.boundingMapRect
            self.map.setRegion(MKCoordinateRegion(rect), animated: true)
        }
        self.locationManager.stopUpdatingLocation()
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.darkGray
        renderer.lineWidth = 3.0
        return renderer
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let userLocation:CLLocation = locations[0] as CLLocation
        manager.stopUpdatingLocation()
        let  sourceLocation = CLLocationCoordinate2D(latitude: userLocation.coordinate.latitude, longitude: userLocation.coordinate.longitude)
        let  destinationLocation = CLLocationCoordinate2D(latitude: self.latt, longitude: self.longg)
        sendNotification()
        showRouteOnMap(pickupCoordinate: sourceLocation,destinationCoordinate: destinationLocation)
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error \(error)")
        locationManager.startUpdatingLocation()
    }
     func sendNotification() {
     // 1
     let content = UNMutableNotificationContent()
     content.title = "Notification for Location"
     content.subtitle = "Navigation "
     content.body = " Notification"
     
     // 2
     let imageName = "applelogo"
     guard let imageURL = Bundle.main.url(forResource: imageName, withExtension: "png") else { return }
     
     let attachment = try! UNNotificationAttachment(identifier: imageName, url: imageURL, options: .none)
     
     content.attachments = [attachment]
     
     // 3
     let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)
     let request = UNNotificationRequest(identifier: "notification.id.01", content: content, trigger: trigger)
     
     // 4
     UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
     }
}

//    func distance(from location: CLLocation, to cordinate: CLLocation) -> CLLocationDistance {
//        let coordinate0 = CLLocation(latitude: 23.3071044, longitude: 77.3625245)
//        let coordinate1 = CLLocation(latitude: 22.7173772, longitude: 75.8069321)
//        let dist = distance(from: coordinate0, to: coordinate1)
//        print(dist)
//        let distanceInMeters = location.distance(from: cordinate)
//        return distanceInMeters
//    }
//        let sourceLocation = CLLocationCoordinate2D(latitude: 23.3071044, longitude: 77.3625245)
//        let destinationLocation = CLLocationCoordinate2D(latitude: 22.7173772, longitude: 75.8069321)

