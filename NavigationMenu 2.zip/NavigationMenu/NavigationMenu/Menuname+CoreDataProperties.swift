//
//  Menuname+CoreDataProperties.swift
//  NavigationMenu
//
//  Created by Workstation 158 on 21/06/19.
//  Copyright © 2019 learn. All rights reserved.
//
//

import Foundation
import CoreData


extension Menuname {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Menuname> {
        return NSFetchRequest<Menuname>(entityName: "Menuname")
    }

    @NSManaged public var image: Data?
    @NSManaged public var menu: String?
    @NSManaged public var menuid: String?
    @NSManaged public var submenuid: Int16
    @NSManaged public var relationship: Relational?

}
