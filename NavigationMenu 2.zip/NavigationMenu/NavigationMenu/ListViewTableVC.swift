//
//  ListViewTableVC.swift
//  NavigationMenu
//
//  Created by Workstation 158 on 11/04/19.
//  Copyright © 2019 learn. All rights reserved.
//

import Foundation
import UIKit
import CoreData
import UserNotifications

class ListViewTableVC: UITableViewController {
    @IBOutlet weak var table: UITableView!
    var window: UIWindow?
    var item :[Any] = []
    var dict = NSMutableDictionary()
    var animatedCellIndex = [Int]()
    let context = ((UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext)
    override func viewDidLoad() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert]) {
            (granted, error) in
            if granted {
                print("yes")
            } else {
                print("No")
            }
        }
    }
    override func viewWillAppear(_ animated: Bool)
    {
        loadDataFromStore()
        tableView.isEditing = true
        tableView.tableFooterView = UIView()
        self.table.reloadData()
    }
    
    func loadDataFromStore () {
        if item.count > 0 {
            item.removeAll()
        }
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Menuname") //Menuname.fetchRequest()
        fetchRequest.returnsObjectsAsFaults = false
        var locations: [NSManagedObject] = []
        do {
            locations = try context.fetch(fetchRequest) as! [NSManagedObject]
            for location in locations
            {
                item.append(location)
                print(location)
            }
        }
        catch {
            print("error executing fetch request: \(error)")
        }        
        self.table.reloadData()
    }
    
     func sendNotification() {
     // 1
     let content = UNMutableNotificationContent()
     content.title = "Notification Tutorial"
     content.subtitle = "from ioscreator.com"
     content.body = " Notification triggered"
     
     let imageName = "applelogo"
     guard let imageURL = Bundle.main.url(forResource: imageName, withExtension: "png") else { return }
     
     let attachment = try! UNNotificationAttachment(identifier: imageName, url: imageURL, options: .none)
     
     content.attachments = [attachment]
     
     let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)
     let request = UNNotificationRequest(identifier: "notification.id.01", content: content, trigger: trigger)

     UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
     }
    @IBAction func btn_next(_ sender: UIBarButtonItem) {
        let navigation = storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.navigationController?.pushViewController(navigation, animated: true)
    }
}
extension UITableViewCell {
    func fadeInAnimation(withDuration duration: Double = 0.1,forIndex index : Int) {
        self.alpha = 0
        UIView.animate(withDuration: duration, delay: (duration * Double(index)),  animations: {
            self.alpha = 1.0
        }, completion: nil)
    }
    func rightInAnimation(withDuration duration: Double = 0.5,withDelay delay : Double = 0.08,forIndex index : Int) {
        self.transform = CGAffineTransform(translationX: self.bounds.width, y: 0)
        UIView.animate(withDuration: duration,delay: delay * Double(index),animations: {
            self.transform = CGAffineTransform(translationX: 0, y: 0)
        })
    }
}

extension ListViewTableVC {
    
    func tableViewSetup() {
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return item.count
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 103.0
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath as IndexPath)
        cell.layer.shadowOffset = CGSize(width: 2, height: 2)
        cell.layer.shadowColor = UIColor.darkGray.cgColor
        cell.layer.shadowRadius = 1
        cell.layer.shadowOpacity = 0.6
        cell.layer.masksToBounds = false
        cell.clipsToBounds = false
        //      let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: customView.self) ,for: indexPath as IndexPath) as! customView
        let dic = item[indexPath.row]  as! NSManagedObject
        let image = dic.value(forKey:"image")
        let lblTitle:UILabel = cell.viewWithTag(97) as! UILabel
        let lblSubTitle:UILabel = cell.viewWithTag(98) as! UILabel
        let imgView:UIImageView = cell.viewWithTag(99) as! UIImageView
        //      UIView.animate(withDuration: 2.0, animations: {
        //          imgView.transform = CGAffineTransform(rotationAngle: (180 * CGFloat(Double.pi)) / 180.0)
        //      })
        imgView.clipsToBounds = true
        imgView.layer.borderWidth = 1.0
        imgView.layer.borderColor = UIColor.darkGray.cgColor
        imgView.layer.cornerRadius = 6
        let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")
        rotationAnimation.fromValue = 0.0
        rotationAnimation.toValue = 2 * Double.pi
        rotationAnimation.duration = 2.0
        imgView.layer.add(rotationAnimation, forKey: nil)
         /*
         let darkBlur = UIBlurEffect(style: .dark)
         // 2
         let blurView = UIVisualEffectView(effect: darkBlur)
         blurView.frame = imgView.bounds
         // 3
         imgView.addSubview(blurView)
         */
        if image != nil {
            imgView.image = UIImage(data: image as! Data, scale: 1.0)
        }
        lblTitle.text = dic.value(forKey: "menu" ) as? String
        lblSubTitle.text = dic.value(forKey: "menuid") as? String
        return cell
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if animatedCellIndex.contains(indexPath.row){
            return
        }
        animatedCellIndex.append(indexPath.row)
        cell.rightInAnimation(forIndex: indexPath.row)
        
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        return true
    }
    
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let itemToMove = item[sourceIndexPath.row]
        item.remove(at: sourceIndexPath.row)
        item.insert(itemToMove, at: destinationIndexPath.row)
    }
   
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]?
    {
        let editAction = UITableViewRowAction(style: .default, title: "Edit", handler: {(action, indexPath) in
            let updatevc = self.storyboard?.instantiateViewController(withIdentifier: "UpdatenaVC") as! UINavigationController
            let temp = self.item[indexPath.row] as! NSManagedObject
            getrecord = temp
            self.present(updatevc, animated: true, completion: nil)
        })
        let deleteAction = UITableViewRowAction(style: .default, title: "Delete", handler: { (action, indexPath) in
            let temp = self.item[indexPath.row] as! NSManagedObject
            let userNAME = temp.value(forKey: "menu")
            let entitydec = NSEntityDescription.entity(forEntityName: "Menuname", in: self.context)
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Menuname")
            request.entity = entitydec
            let pred = NSPredicate(format: "menu = %@", userNAME as! CVarArg)
            request.predicate = pred
            do
            {
                let result = try self.context.fetch(request)
                if result.count > 0
                {
                    let manage = result[0] as! NSManagedObject
                    self.context.delete(manage)
                    try self.context.save()
                    print("Record Deleted")
                }
                else
                {
                    print("Record Not Found")
                }
            }
            catch {}
            self.item.remove(at: indexPath.row)
            self.table.deleteRows(at: [indexPath], with: .middle)
            self.table.reloadData()
        })
        return [deleteAction, editAction]
    }
}
