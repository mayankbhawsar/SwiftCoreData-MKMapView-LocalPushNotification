//
//  Relational+CoreDataProperties.swift
//  NavigationMenu
//
//  Created by Workstation 158 on 21/06/19.
//  Copyright © 2019 learn. All rights reserved.
//
//

import Foundation
import CoreData


extension Relational {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Relational> {
        return NSFetchRequest<Relational>(entityName: "Relational")
    }

    @NSManaged public var submenuid: Int16
    @NSManaged public var submenuname: String?
    @NSManaged public var menuname: Menuname?

}
