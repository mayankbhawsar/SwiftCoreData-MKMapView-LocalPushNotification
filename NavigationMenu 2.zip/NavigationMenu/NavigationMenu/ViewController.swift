//
//  ViewController.swift
//  NavigationMenu
//
//  Created by Workstation 158 on 10/04/19.
//  Copyright © 2019 learn. All rights reserved.
//

import UIKit
import CoreData
import LocalAuthentication

extension UIImageView {
    func setRounded() {
        self.layer.cornerRadius = (self.frame.size.width / 2)
        self.layer.masksToBounds = true
    }
}
//196825508
class ViewController: UIViewController,UIAlertViewDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UITextFieldDelegate {
    @IBOutlet weak var txtDate: UITextField!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var txtMenuName: UITextField!
    @IBOutlet weak var txtMenuID: UITextField!
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var btnImage: UIButton!
    
    let imagepicker = UIImagePickerController()
    let datePicker = UIDatePicker()
     /*
     // Change the Color of the Status Bar
     override var preferredStatusBarStyle: UIStatusBarStyle {
     return .default
     }
     override func viewDidAppear(_ animated: Bool) {
     navigationController?.navigationBar.barStyle = .default
     }*/
    override func viewDidLoad() {
       
        txtMenuName.placeholder = "Header"
        txtMenuID.placeholder = "Title"
        txtDate.placeholder = "DATE"
        super.viewDidLoad()
        imgView.layer.cornerRadius = imgView.frame.size.height/2
        imgView.clipsToBounds = true
        imgView.layer.borderWidth = 3.0
        imgView.layer.borderColor = UIColor.black.cgColor
        setDatePicker()
        /*   let a = [4,3,2,1,5,4]
         a = a.sorted { $0 > $1 }
         print(a) //23.3071044,77.3625245
         print( a.sorted(by: >)) */
    }
    
    func viewWillAppear()  {
        super.viewWillAppear(true)
    }
    
    func setDatePicker() {
        //Format Date
        datePicker.datePickerMode = .date
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneDatePicker));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker));
        toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        txtDate.inputAccessoryView = toolbar
        txtDate.inputView = datePicker
    }
    @objc func doneDatePicker() {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd MMM yyyy"
        txtDate.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
//        txtDate.isUserInteractionEnabled = false
    }
    
    @objc func cancelDatePicker() {
        self.view.endEditing(true)
    }
    
    // Factorial
    func factorial(of num: Int) -> Int {
        if num == 1 {
            return 1
        } else {
            return num * factorial(of:num - 1)
        }
    }
    
    // function for compare Two Array Element
    func array() {
        let array1 = ["a","b","c","d"]
        let array2 = ["a","c","c","d"]
        let result = zip(array1, array2).enumerated().filter() {
            $1.0 == $1.1
            }.map{$0.0}
        print(result)
    }
    // Check the prime number
    func isPrime(_ number: Int) -> Bool {
        // right below
        if number == 2 || number == 3 { return true }
        let maxDivider = Int(sqrt(Double(number)))
        return number > 1 && !(2...maxDivider).contains { number % $0 == 0 }
    }
    // Check the prime number  //single line code
    func prime(_ number: Int) -> Bool {
        return (1...number).filter({number % $0 == 0}).count <= 2
    }
    // print * pyramid in swift 4
    func printS()  {
        let treeHeight = 5
        let treeWidth = treeHeight * 2 - 1
        for lineNumber in 1...treeHeight {
            // How many asterisks to print
            let stars = 2 * lineNumber - 1
            var line = ""
            // Half the non-star space
            let spaces = (treeWidth - stars) / 2
            if spaces > 0 {
                line = String(repeating: " ", count: spaces)
            }
            
            line += String(repeating: "*", count: stars)
            print (line)
        }
    }
    
    func fibonaci(n: Int) {
        var fiboNumberOne = 1
        var fiboNumberTwo = 0
        for _ in 0..<n
        {
            let temp = fiboNumberOne + fiboNumberTwo
            fiboNumberOne = fiboNumberTwo
            fiboNumberTwo = temp
            print("Fibonaci \(fiboNumberTwo)")
        }
    }
    
    @IBAction func saveDetails(_ sender: Any) {
        if txtMenuName.text?.count == 0 {
            let alert = coreDataFunction().alertMessage(alertmsg: "Not Blank")
            self.present(alert, animated: true, completion: nil)
        }
        else if txtMenuID.text?.count == 0 {
            let alert = coreDataFunction().alertMessage(alertmsg: "Not Blank")
            self.present(alert, animated: true, completion: nil)
        }
        else {
            let result = coreDataFunction().someEntityExists(menuname: txtMenuName.text! as String)
            if result == true {
                let alert = coreDataFunction().alertMessage(alertmsg: "Already Exist")
                self.present(alert, animated: true, completion: nil)
            }
            else {
                var imageData = self.imgView.image!.jpegData(compressionQuality: 1.0) as Data?
                let save = coreDataFunction().saveDataIntoCoreDataEntity(imgData: imageData!, menu: txtMenuName.text!, menuID: txtMenuID.text!)
                if save == true {
                    txtMenuID.text = ""
                    txtMenuName.text = ""
                    imageData?.removeAll()
                    imgView.image = UIImage(data: imageData!)
                    let alert = coreDataFunction().alertMessage(alertmsg: "Successfully Added")
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    @IBAction func ChooseImageFrom(_ sender: Any) {
        let alert:UIAlertController = UIAlertController(title: "Choose Image", message: nil, preferredStyle:.alert)
        let cameraAction = UIAlertAction(title: "From Camera", style: .default)
        {
            UIAlertAction in
            self.openCamera()
        }
        let gallaryAction = UIAlertAction(title: "BY Gallary", style: .default)
        {
            UIAlertAction in
            self.openGallary()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        {
            UIAlertAction in
        }
        // Add the actions
        imagepicker.delegate = self
        alert.addAction(cameraAction)
        alert.addAction(gallaryAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    func openCamera()
    {
        if(UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera))
        {
            imagepicker.sourceType = UIImagePickerController.SourceType.camera
            self.present(imagepicker, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "Alert", message: "You don't have camera", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    func openGallary()
    {
        imagepicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        self.present(imagepicker, animated: true, completion: nil)
    }
    
    //PickerView Delegate Methods
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            self.imgView.contentMode = .scaleAspectFit
            self.imgView.image = pickedImage
        }
        dismiss(animated: true, completion: nil)
    }
    private func imagePickerControllerDidCancel(picker: UIImagePickerController)
    {
        print("picker cancel.")
    }
   
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
//        txtDate.resignFirstResponder()
        print("TextField should begin editing method called")
        return true
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
//        textField.resignFirstResponder()
        switch textField {
        case txtDate:
            txtDate.resignFirstResponder()
            txtDate.inputView = datePicker
        default:
            break
        }
        return true
    }
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//        return false
//    }
}
