//
//  customView.swift
//  NavigationMenu
//
//  Created by Workstation 158 on 08/05/19.
//  Copyright © 2019 learn. All rights reserved.
//

import Foundation
import UIKit

class customView: UITableViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
